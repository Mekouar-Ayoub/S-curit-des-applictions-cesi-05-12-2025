const express = require('express');
const { Pool } = require('pg');
const config = require('../config/config.js');

const app = express();
const pool = new Pool(config.database);

app.use(express.json());

// ⚠️ VULNÉRABILITÉ : Contrôle d'accès côté client uniquement
function checkAdminAccess(req, res, next) {
    // ⚠️ FAIBLESSE MAJEURE : Vérification basée sur les en-têtes HTTP
    // Un attaquant peut facilement manipuler ces en-têtes
    const userRole = req.headers['x-user-role'];
    const isAdmin = req.headers['x-is-admin'];

    // ⚠️ Pas de vérification en base de données !
    if (userRole === 'admin' || isAdmin === 'true') {
        console.log('Accès admin accordé via en-têtes');
        next();
    } else {
        res.status(403).json({
            success: false,
            message: 'Accès administrateur requis'
        });
    }
}

// ⚠️ VULNÉRABILITÉ : API admin avec contrôle d'accès défaillant
app.get('/api/admin/users', checkAdminAccess, async (req, res) => {
    try {
        // ⚠️ Exposition de données sensibles de tous les utilisateurs
        const query = `
            SELECT user_id, username, email, password_hash, role, 
                   phone, address, created_at, last_login
            FROM users
            ORDER BY created_at DESC
        `;

        const result = await pool.query(query);

        res.json({
            success: true,
            message: 'Liste des utilisateurs (admin)',
            users: result.rows    // ⚠️ Inclut les hashes de mots de passe !
        });

    } catch (error) {
        console.error('Erreur récupération utilisateurs admin :', error);
        res.status(500).json({
            success: false,
            message: 'Erreur serveur'
        });
    }
});

// ⚠️ VULNÉRABILITÉ : Suppression d'utilisateur sans vérifications
app.delete('/api/admin/users/:user_id', checkAdminAccess, async (req, res) => {
    const { user_id } = req.params;

    try {
        // ⚠️ PAS DE PROTECTION contre la suppression d'autres admins
        // Un attaquant pourrait supprimer des comptes administrateurs
        const deleteQuery = 'DELETE FROM users WHERE user_id = $1 RETURNING username, role';
        const result = await pool.query(deleteQuery, [user_id]);

        if (result.rows.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Utilisateur non trouvé'
            });
        }

        const deletedUser = result.rows[0];

        res.json({
            success: true,
            message: `Utilisateur ${deletedUser.username} supprimé`,
            deleted_user: deletedUser
        });

        console.log(`Utilisateur supprimé : ${deletedUser.username} (${deletedUser.role})`);

    } catch (error) {
        console.error('Erreur suppression utilisateur :', error);
        res.status(500).json({
            success: false,
            message: 'Erreur serveur'
        });
    }
});

// ⚠️ VULNÉRABILITÉ : Modification de rôle sans restrictions
app.put('/api/admin/users/:user_id/role', checkAdminAccess, async (req, res) => {
    const { user_id } = req.params;
    const { role } = req.body;

    try {
        // ⚠️ Aucune validation du rôle ou restrictions
        // Un attaquant peut donner des privilèges admin à n'importe qui
        const updateQuery = `
            UPDATE users 
            SET role = $1, updated_at = NOW() 
            WHERE user_id = $2 
            RETURNING username, role
        `;

        const result = await pool.query(updateQuery, [role, user_id]);

        if (result.rows.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Utilisateur non trouvé'
            });
        }

        res.json({
            success: true,
            message: 'Rôle mis à jour',
            user: result.rows[0]
        });

    } catch (error) {
        console.error('Erreur modification rôle :', error);
        res.status(500).json({
            success: false,
            message: 'Erreur serveur'
        });
    }
});

module.exports = app;