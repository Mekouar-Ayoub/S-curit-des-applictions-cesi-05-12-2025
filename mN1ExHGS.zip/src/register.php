<?php
// Configuration de base de données
$host = 'localhost';
$dbname = 'shopcesi';
$username = 'shopcesi_user';
$password = 'password123'; // ⚠️ VULNÉRABILITÉ : Mot de passe faible hardcodé

try {
    $pdo = new PDO("pgsql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Erreur de connexion : " . $e->getMessage());
}

// Traitement du formulaire d'inscription
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // ⚠️ VULNÉRABILITÉ MASS ASSIGNMENT : Acceptation de tous les champs POST
    // Un attaquant peut injecter des champs comme 'role', 'is_admin', etc.
    $userData = [];
    foreach ($_POST as $key => $value) {
        $userData[$key] = $value; // Aucune validation des champs autorisés
    }

    // Champs supposés normaux
    $username = $userData['username'] ?? '';
    $email = $userData['email'] ?? '';
    $password = $userData['password'] ?? '';
    $bio = $userData['bio'] ?? ''; // ⚠️ VULNÉRABILITÉ XSS : Bio non échappée

    // ⚠️ VULNÉRABILITÉ MASS ASSIGNMENT : Champs additionnels non contrôlés
    $role = $userData['role'] ?? 'user'; // Un attaquant peut définir 'admin'
    $credits = $userData['credits'] ?? 0; // Un attaquant peut s'auto-créditer
    $is_verified = $userData['is_verified'] ?? false;

    // Validation minimale (insuffisante)
    if (empty($username) || empty($email) || empty($password)) {
        $error = "Tous les champs obligatoires doivent être remplis.";
    } else {
        try {
            // Hashage du mot de passe (bonne pratique conservée)
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

            // ⚠️ VULNÉRABILITÉ XSS STORED : Bio stockée sans échappement HTML
            // Le contenu malveillant sera exécuté lors de l'affichage
            $stmt = $pdo->prepare("
                INSERT INTO users (username, email, password_hash, bio, role, credits, is_verified, created_at) 
                VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
            ");

            $stmt->execute([
                $username, 
                $email, 
                $hashedPassword, 
                $bio,           // ⚠️ Pas d'échappement HTML ici
                $role,          // ⚠️ Contrôlé par l'utilisateur
                $credits,       // ⚠️ Contrôlé par l'utilisateur
                $is_verified    // ⚠️ Contrôlé par l'utilisateur
            ]);

            $success = "Inscription réussie ! Bienvenue " . htmlspecialchars($username) . ".";

            // Log pour debugging (expose des infos sensibles)
            error_log("Nouvel utilisateur : $username, Role: $role, Credits: $credits");

        } catch(PDOException $e) {
            $error = "Erreur lors de l'inscription : " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>ShopCESI - Inscription</title>
</head>
<body>
    <h1>Inscription ShopCESI</h1>

    <?php if (isset($error)): ?>
        <div style="color: red;"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <?php if (isset($success)): ?>
        <div style="color: green;"><?= $success ?></div>
    <?php endif; ?>

    <form method="POST">
        <p>
            <label>Nom d'utilisateur :</label><br>
            <input type="text" name="username" required>
        </p>

        <p>
            <label>Email :</label><br>
            <input type="email" name="email" required>
        </p>

        <p>
            <label>Mot de passe :</label><br>
            <input type="password" name="password" required>
        </p>

        <p>
            <label>Bio (optionnel) :</label><br>
            <textarea name="bio" placeholder="Parlez-nous de vous..."></textarea>
        </p>

        <!-- ⚠️ VULNÉRABILITÉ : Champs cachés que l'utilisateur peut modifier -->
        <input type="hidden" name="role" value="user">
        <input type="hidden" name="credits" value="0">
        <input type="hidden" name="is_verified" value="false">

        <p>
            <input type="submit" value="S'inscrire">
        </p>
    </form>

    <p><a href="login.html">Déjà inscrit ? Se connecter</a></p>
</body>
</html>