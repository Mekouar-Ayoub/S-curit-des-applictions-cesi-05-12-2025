const express = require('express');
const { Pool } = require('pg');
const bcrypt = require('bcrypt');
const config = require('../config/config.js');

const app = express();
const pool = new Pool(config.database);

app.use(express.json());

// Middleware d'authentification
function checkAuth(req, res, next) {
    if (req.session && req.session.userId) {
        req.userId = req.session.userId;
        next();
    } else {
        res.status(401).json({
            success: false,
            message: 'Authentification requise'
        });
    }
}

// ⚠️ VULNÉRABILITÉ : Changement de mot de passe sans rate limiting
app.post('/api/profile/change-password', checkAuth, async (req, res) => {
    const { current_password, new_password } = req.body;

    // ⚠️ PAS DE RATE LIMITING : Un attaquant peut faire des tentatives en masse
    // Devrait limiter le nombre de tentatives par IP/utilisateur/temps

    try {
        // Récupérer l'utilisateur actuel
        const userQuery = 'SELECT password_hash FROM users WHERE user_id = $1';
        const userResult = await pool.query(userQuery, [req.userId]);

        if (userResult.rows.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Utilisateur non trouvé'
            });
        }

        const user = userResult.rows[0];

        // Vérifier le mot de passe actuel
        const isValidPassword = await bcrypt.compare(current_password, user.password_hash);

        if (!isValidPassword) {
            // ⚠️ PAS DE DÉLAI ou LIMITATION après échec
            console.log(`Tentative de changement MDP échoué pour utilisateur ${req.userId} depuis ${req.ip}`);

            return res.status(401).json({
                success: false,
                message: 'Mot de passe actuel incorrect'
            });
        }

        // Hasher le nouveau mot de passe
        const saltRounds = 10;
        const hashedNewPassword = await bcrypt.hash(new_password, saltRounds);

        // Mettre à jour le mot de passe
        const updateQuery = 'UPDATE users SET password_hash = $1, updated_at = NOW() WHERE user_id = $2';
        await pool.query(updateQuery, [hashedNewPassword, req.userId]);

        res.json({
            success: true,
            message: 'Mot de passe mis à jour avec succès'
        });

        console.log(`Mot de passe changé avec succès pour utilisateur ${req.userId}`);

    } catch (error) {
        console.error('Erreur changement mot de passe :', error);
        res.status(500).json({
            success: false,
            message: 'Erreur serveur'
        });
    }
});

// Récupération des informations de profil
app.get('/api/profile', checkAuth, async (req, res) => {
    try {
        const query = `
            SELECT user_id, username, email, created_at, updated_at, 
                   bio, phone, address, role
            FROM users 
            WHERE user_id = $1
        `;

        const result = await pool.query(query, [req.userId]);

        if (result.rows.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Profil non trouvé'
            });
        }

        res.json({
            success: true,
            profile: result.rows[0]
        });

    } catch (error) {
        console.error('Erreur récupération profil :', error);
        res.status(500).json({
            success: false,
            message: 'Erreur serveur'
        });
    }
});

module.exports = app;