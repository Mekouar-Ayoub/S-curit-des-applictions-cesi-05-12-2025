const express = require('express');
const { Pool } = require('pg');
const config = require('../config/config.js');

const app = express();
const pool = new Pool(config.database);

app.use(express.json());

// Middleware basique d'authentification
function checkAuth(req, res, next) {
    if (req.session && req.session.userId) {
        req.userId = req.session.userId;
        next();
    } else {
        res.status(401).json({
            success: false,
            message: 'Authentification requise'
        });
    }
}

// ⚠️ VULNÉRABILITÉ XSS REFLECTED : Paramètre search non échappé
app.get('/api/comments/search', async (req, res) => {
    const { search, product_id } = req.query;

    try {
        let query = `
            SELECT c.comment_id, c.content, c.rating, c.created_at,
                   u.username, p.name as product_name
            FROM comments c
            LEFT JOIN users u ON c.user_id = u.user_id
            LEFT JOIN products p ON c.product_id = p.product_id
            WHERE 1=1
        `;

        const params = [];

        if (product_id) {
            query += ` AND c.product_id = $${params.length + 1}`;
            params.push(product_id);
        }

        if (search) {
            query += ` AND c.content ILIKE $${params.length + 1}`;
            params.push(`%${search}%`);
        }

        const result = await pool.query(query, params);

        // ⚠️ VULNÉRABILITÉ XSS REFLECTED : Paramètre search renvoyé sans échappement
        res.json({
            success: true,
            search_term: search,    // ⚠️ Terme de recherche non échappé renvoyé tel quel
            count: result.rows.length,
            message: `Résultats pour : ${search}`, // ⚠️ Injection XSS possible ici
            comments: result.rows
        });

    } catch (error) {
        console.error('Erreur recherche commentaires :', error);
        res.status(500).json({
            success: false,
            message: 'Erreur serveur'
        });
    }
});

// ⚠️ VULNÉRABILITÉ CSRF : Pas de protection CSRF sur POST
app.post('/api/comments', checkAuth, async (req, res) => {
    const { product_id, content, rating } = req.body;

    // ⚠️ PAS DE VÉRIFICATION DE TOKEN CSRF
    // Un site malveillant peut déclencher cette action à l'insu de l'utilisateur

    try {
        const insertQuery = `
            INSERT INTO comments (user_id, product_id, content, rating, created_at)
            VALUES ($1, $2, $3, $4, NOW())
            RETURNING comment_id, created_at
        `;

        const result = await pool.query(insertQuery, [
            req.userId,
            product_id,
            content,
            rating
        ]);

        res.json({
            success: true,
            message: 'Commentaire ajouté avec succès',
            comment_id: result.rows[0].comment_id,
            created_at: result.rows[0].created_at
        });

        console.log(`Nouveau commentaire par utilisateur ${req.userId} sur produit ${product_id}`);

    } catch (error) {
        console.error('Erreur ajout commentaire :', error);
        res.status(500).json({
            success: false,
            message: 'Erreur lors de l'ajout du commentaire'
        });
    }
});

// ⚠️ VULNÉRABILITÉ CSRF : Suppression sans protection CSRF
app.delete('/api/comments/:comment_id', checkAuth, async (req, res) => {
    const { comment_id } = req.params;

    // ⚠️ PAS DE TOKEN CSRF : Action sensible non protégée
    // Un attaquant peut faire supprimer des commentaires à l'insu de la victime

    try {
        const deleteQuery = `
            DELETE FROM comments 
            WHERE comment_id = $1 AND user_id = $2
            RETURNING comment_id
        `;

        const result = await pool.query(deleteQuery, [comment_id, req.userId]);

        if (result.rows.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Commentaire non trouvé ou non autorisé'
            });
        }

        res.json({
            success: true,
            message: 'Commentaire supprimé'
        });

    } catch (error) {
        console.error('Erreur suppression commentaire :', error);
        res.status(500).json({
            success: false,
            message: 'Erreur serveur'
        });
    }
});

module.exports = app;