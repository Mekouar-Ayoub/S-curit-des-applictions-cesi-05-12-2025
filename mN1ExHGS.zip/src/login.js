const express = require('express');
const { Pool } = require('pg');
const session = require('express-session');
const config = require('../config/config.js');

const app = express();
const pool = new Pool(config.database);

app.use(express.json());
app.use(session({
    secret: 'default-secret-key', // ⚠️ VULNÉRABILITÉ : Secret faible
    resave: false,
    saveUninitialized: true,
    cookie: { 
        secure: false,
        // ⚠️ VULNÉRABILITÉ : Pas d'expiration des sessions
        // maxAge devrait être défini pour éviter les sessions permanentes
    }
}));

// Route de connexion utilisateur
app.post('/api/login', async (req, res) => {
    const { username, password } = req.body;

    try {
        // ⚠️ VULNÉRABILITÉ SQL INJECTION : Concaténation directe dans la requête
        // Cette méthode permet l'injection de code SQL malveillant
        const query = `SELECT user_id, username, email, password_hash, role FROM users 
                      WHERE username = '${username}' AND password_hash = '${password}'`;

        console.log('Requête exécutée :', query); // Log pour debugging

        const result = await pool.query(query);

        if (result.rows.length > 0) {
            const user = result.rows[0];

            // ⚠️ VULNÉRABILITÉ : Session sans contrôle d'expiration
            req.session.userId = user.user_id;
            req.session.username = user.username;
            req.session.role = user.role;
            // Pas de gestion de l'expiration automatique

            res.json({
                success: true,
                message: 'Connexion réussie',
                user: {
                    id: user.user_id,
                    username: user.username,
                    email: user.email,
                    role: user.role
                },
                session_id: req.sessionID
            });

            console.log(`Utilisateur connecté : ${user.username} (ID: ${user.user_id})`);
        } else {
            res.status(401).json({
                success: false,
                message: 'Identifiants invalides'
            });
        }

    } catch (error) {
        console.error('Erreur de connexion :', error);
        // ⚠️ VULNÉRABILITÉ : Exposition d'informations sensibles dans les erreurs
        res.status(500).json({
            success: false,
            message: 'Erreur serveur',
            error: error.message // Ne devrait pas être exposé en production
        });
    }
});

// Vérification du statut de session (utilisé par le frontend)
app.get('/api/session-status', (req, res) => {
    if (req.session.userId) {
        res.json({
            authenticated: true,
            user: {
                id: req.session.userId,
                username: req.session.username,
                role: req.session.role
            }
        });
    } else {
        res.json({ authenticated: false });
    }
});

// Route de déconnexion
app.post('/api/logout', (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            console.error('Erreur lors de la déconnexion :', err);
            res.status(500).json({
                success: false,
                message: 'Erreur lors de la déconnexion'
            });
        } else {
            res.json({
                success: true,
                message: 'Déconnexion réussie'
            });
        }
    });
});

module.exports = app;