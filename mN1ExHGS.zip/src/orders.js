const express = require('express');
const { Pool } = require('pg');
const config = require('../config/config.js');

const app = express();
const pool = new Pool(config.database);

app.use(express.json());

// Middleware de vérification de session (défaillant)
function checkAuth(req, res, next) {
    // ⚠️ VULNÉRABILITÉ : Vérification d'authentification insuffisante
    if (req.session && req.session.userId) {
        req.userId = req.session.userId;
        next();
    } else {
        res.status(401).json({
            success: false,
            message: 'Authentification requise'
        });
    }
}

// ⚠️ VULNÉRABILITÉ IDOR : Accès aux commandes d'autres utilisateurs
// API pour récupérer une commande par ID (sans vérification de propriétaire)
app.get('/api/orders/:order_id', checkAuth, async (req, res) => {
    const { order_id } = req.params;

    try {
        // ⚠️ PAS DE VÉRIFICATION : L'utilisateur peut accéder à n'importe quelle commande
        // Il devrait y avoir une condition WHERE user_id = req.userId
        const query = `
            SELECT o.*, u.username, u.email, u.phone, u.address
            FROM orders o
            LEFT JOIN users u ON o.user_id = u.user_id
            WHERE o.order_id = $1
        `;

        const result = await pool.query(query, [order_id]);

        if (result.rows.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Commande non trouvée'
            });
        }

        const order = result.rows[0];

        // ⚠️ VULNÉRABILITÉ : Exposition de données personnelles d'autres utilisateurs
        res.json({
            success: true,
            order: {
                id: order.order_id,
                user_id: order.user_id,         // ⚠️ ID utilisateur exposé
                total: order.total_amount,
                status: order.status,
                created_at: order.created_at,
                customer_info: {                // ⚠️ Infos client exposées
                    username: order.username,
                    email: order.email,
                    phone: order.phone,
                    address: order.address
                }
            }
        });

    } catch (error) {
        console.error('Erreur récupération commande :', error);
        res.status(500).json({
            success: false,
            message: 'Erreur serveur'
        });
    }
});

// ⚠️ VULNÉRABILITÉ BROKEN ACCESS CONTROL : Modification de commandes d'autres utilisateurs
app.put('/api/orders/:order_id/status', checkAuth, async (req, res) => {
    const { order_id } = req.params;
    const { status } = req.body;

    try {
        // ⚠️ AUCUNE VÉRIFICATION de propriété de la commande
        // Un utilisateur peut modifier le statut des commandes d'autres utilisateurs
        const updateQuery = `
            UPDATE orders 
            SET status = $1, updated_at = NOW()
            WHERE order_id = $2
            RETURNING *
        `;

        const result = await pool.query(updateQuery, [status, order_id]);

        if (result.rows.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Commande non trouvée'
            });
        }

        res.json({
            success: true,
            message: 'Statut mis à jour',
            order: result.rows[0]
        });

        console.log(`Commande ${order_id} modifiée par l'utilisateur ${req.userId}`);

    } catch (error) {
        console.error('Erreur modification commande :', error);
        res.status(500).json({
            success: false,
            message: 'Erreur serveur'
        });
    }
});

// ⚠️ VULNÉRABILITÉ : Listage de toutes les commandes sans filtrage
app.get('/api/orders', checkAuth, async (req, res) => {
    try {
        // ⚠️ BROKEN ACCESS CONTROL : Retourne TOUTES les commandes, pas seulement celles de l'utilisateur
        // Devrait avoir WHERE user_id = req.userId
        const query = `
            SELECT o.order_id, o.user_id, o.total_amount, o.status, o.created_at,
                   u.username, u.email, COUNT(oi.item_id) as item_count
            FROM orders o
            LEFT JOIN users u ON o.user_id = u.user_id
            LEFT JOIN order_items oi ON o.order_id = oi.order_id
            GROUP BY o.order_id, u.user_id, u.username, u.email
            ORDER BY o.created_at DESC
            LIMIT 100
        `;

        const result = await pool.query(query);

        res.json({
            success: true,
            count: result.rows.length,
            orders: result.rows    // ⚠️ Toutes les commandes de tous les utilisateurs !
        });

    } catch (error) {
        console.error('Erreur listage commandes :', error);
        res.status(500).json({
            success: false,
            message: 'Erreur serveur'
        });
    }
});

module.exports = app;