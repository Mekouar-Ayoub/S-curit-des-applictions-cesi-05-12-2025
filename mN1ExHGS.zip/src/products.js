const express = require('express');
const { Pool } = require('pg');
const config = require('../config/config.js');

const app = express();
const pool = new Pool(config.database);

app.use(express.json());

// API de recherche de produits
app.get('/api/products/search', async (req, res) => {
    const { query, category, min_price, max_price } = req.query;

    try {
        let sqlQuery = `
            SELECT p.product_id, p.name, p.description, p.price, p.category, p.stock, 
                   p.created_at, p.updated_at,
                   u.username as seller_name, u.email as seller_email, 
                   u.password_hash, u.role, u.phone, u.address
            FROM products p 
            LEFT JOIN users u ON p.seller_id = u.user_id 
            WHERE 1=1
        `;

        const params = [];

        // ⚠️ VULNÉRABILITÉ SQL INJECTION : Concaténation directe des paramètres
        if (query) {
            sqlQuery += ` AND (p.name ILIKE '%${query}%' OR p.description ILIKE '%${query}%')`;
            // CORRECT serait : sqlQuery += ` AND (p.name ILIKE $${params.length+1} OR p.description ILIKE $${params.length+2})`;
            // params.push(`%${query}%`, `%${query}%`);
        }

        if (category) {
            sqlQuery += ` AND p.category = '${category}'`; // ⚠️ Injection possible ici aussi
        }

        if (min_price) {
            sqlQuery += ` AND p.price >= ${min_price}`; // ⚠️ Injection numérique possible
        }

        if (max_price) {
            sqlQuery += ` AND p.price <= ${max_price}`; // ⚠️ Injection numérique possible
        }

        sqlQuery += ' ORDER BY p.created_at DESC LIMIT 50';

        console.log('Requête SQL exécutée :', sqlQuery); // Log dangereux en production

        const result = await pool.query(sqlQuery, params);

        // ⚠️ VULNÉRABILITÉ EXCESSIVE DATA EXPOSURE : 
        // Retourne des données sensibles qui ne devraient pas être exposées
        res.json({
            success: true,
            count: result.rows.length,
            products: result.rows.map(product => ({
                // Données normales
                id: product.product_id,
                name: product.name,
                description: product.description,
                price: product.price,
                category: product.category,
                stock: product.stock,
                created_at: product.created_at,

                // ⚠️ DONNÉES SENSIBLES EXPOSÉES :
                seller: {
                    username: product.seller_name,
                    email: product.seller_email,        // ⚠️ Email du vendeur exposé
                    password_hash: product.password_hash, // ⚠️ Hash du mot de passe exposé !
                    role: product.role,                 // ⚠️ Rôle système exposé
                    phone: product.phone,               // ⚠️ Téléphone exposé
                    address: product.address            // ⚠️ Adresse exposée
                }
            }))
        });

    } catch (error) {
        console.error('Erreur recherche produits :', error);

        // ⚠️ VULNÉRABILITÉ : Exposition d'erreurs SQL détaillées
        res.status(500).json({
            success: false,
            message: 'Erreur lors de la recherche',
            error: error.message,      // ⚠️ Message d'erreur SQL exposé
            query: sqlQuery,           // ⚠️ Requête SQL exposée !
            details: error.detail      // ⚠️ Détails techniques exposés
        });
    }
});

// API de détails d'un produit
app.get('/api/products/:id', async (req, res) => {
    const { id } = req.params;

    try {
        // ⚠️ VULNÉRABILITÉ SQL INJECTION dans les paramètres d'URL
        const query = `
            SELECT p.*, u.username, u.email, u.password_hash, u.phone, u.address,
                   COUNT(r.review_id) as review_count,
                   AVG(r.rating) as avg_rating
            FROM products p
            LEFT JOIN users u ON p.seller_id = u.user_id
            LEFT JOIN reviews r ON p.product_id = r.product_id
            WHERE p.product_id = ${id}
            GROUP BY p.product_id, u.user_id
        `;

        const result = await pool.query(query);

        if (result.rows.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Produit non trouvé'
            });
        }

        const product = result.rows[0];

        // ⚠️ EXCESSIVE DATA EXPOSURE : Encore plus de données sensibles
        res.json({
            success: true,
            product: {
                ...product,                          // ⚠️ Tous les champs BDD exposés
                seller_password_hash: product.password_hash, // ⚠️ Hash mot de passe
                seller_private_info: {               // ⚠️ Groupement d'infos privées
                    email: product.email,
                    phone: product.phone,
                    address: product.address
                }
            }
        });

    } catch (error) {
        console.error('Erreur détail produit :', error);
        res.status(500).json({
            success: false,
            message: 'Erreur serveur',
            sql_error: error.message,    // ⚠️ Erreur SQL exposée
            query_executed: query        // ⚠️ Requête exposée
        });
    }
});

module.exports = app;