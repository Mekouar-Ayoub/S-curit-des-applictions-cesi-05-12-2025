# ShopCESI - Projet d'Audit de Sécurité
## INFAL 251 - Sécurité des Systèmes Applicatifs

> ⚠️ **ATTENTION** : Ce code contient des vulnérabilités intentionnelles à des fins pédagogiques. 
> **NE PAS utiliser en production !**

---

## 🎯 Objectif du Projet

Ce projet fait partie du **Module 6 - Projet Final** du cours INFAL 251. L'objectif est d'effectuer un audit de sécurité complet sur l'application e-commerce ShopCESI et d'identifier **10 à 12 vulnérabilités** réparties dans 8 fichiers source.

## 📁 Structure du Projet

```
shopcesi_vulnerable_code/
├── README.md                    # Ce fichier
├── package.json                 # Dépendances Node.js
├── src/                         # Code source de l'application
│   ├── login.js                 # Authentification utilisateur
│   ├── register.php             # Inscription utilisateur
│   ├── products.js              # Gestion des produits
│   ├── orders.js                # Gestion des commandes
│   ├── comments.js              # Système de commentaires
│   ├── profile.js               # Gestion du profil utilisateur
│   └── admin.js                 # Fonctions d'administration
└── config/
    └── config.js                # Configuration de l'application
```

## 🛠️ Installation et Démarrage

### Prérequis
- Node.js (version 14+)
- PostgreSQL
- PHP (pour register.php)

### Installation
```bash
# Cloner ou extraire le projet
cd shopcesi_vulnerable_code

# Installer les dépendances Node.js
npm install

# Configurer la base de données PostgreSQL
# (Voir config/config.js pour les paramètres de connexion)
```

### Configuration Base de Données
```sql
-- Créer la base de données
CREATE DATABASE shopcesi;
CREATE USER shopcesi_user WITH ENCRYPTED PASSWORD 'SuperSecretPassword123!';
GRANT ALL PRIVILEGES ON DATABASE shopcesi TO shopcesi_user;
```

## 🎯 Mission d'Audit de Sécurité

En tant qu'étudiants, vous devez :

1. **Analyser chaque fichier source** pour identifier les vulnérabilités
2. **Documenter vos découvertes** avec :
   - Type de vulnérabilité (selon OWASP Top 10)
   - Localisation exacte (fichier, ligne)
   - Impact potentiel
   - Solution recommandée
3. **Prioriser les vulnérabilités** par criticité
4. **Proposer un plan de correction**

## 🔍 Liste des Vulnérabilités à Identifier

> **Note** : Cette section ne révèle pas les solutions, seulement les types de vulnérabilités présentes.

### Vulnérabilités par Catégorie OWASP Top 10 2021

#### A01 - Broken Access Control
- [ ] Contrôles d'accès défaillants
- [ ] Élévation de privilèges
- [ ] IDOR (Insecure Direct Object Reference)

#### A02 - Cryptographic Failures  
- [ ] Secrets hardcodés
- [ ] Stockage de données sensibles non sécurisé

#### A03 - Injection
- [ ] SQL Injection (plusieurs occurrences)
- [ ] Injection dans différents contextes

#### A04 - Insecure Design
- [ ] Absence de rate limiting
- [ ] Configuration de sécurité faible

#### A05 - Security Misconfiguration
- [ ] Configuration CORS permissive
- [ ] Paramètres de sécurité inadéquats

#### A07 - Identification and Authentication Failures
- [ ] Gestion de session défaillante
- [ ] Authentification cassée

#### A08 - Software and Data Integrity Failures
- [ ] Validation des données insuffisante

#### A10 - Server-Side Request Forgery (SSRF)
- [ ] Exposition d'informations sensibles

### Vulnérabilités Spécifiques à Rechercher

#### Injection et XSS
- [ ] **SQL Injection** : Rechercher les requêtes SQL non paramétrées
- [ ] **XSS Stored** : Données stockées sans échappement
- [ ] **XSS Reflected** : Paramètres renvoyés sans validation

#### Contrôle d'Accès
- [ ] **IDOR** : Accès aux ressources d'autres utilisateurs
- [ ] **Broken Access Control** : Vérifications d'autorisation insuffisantes
- [ ] **Mass Assignment** : Acceptation de paramètres non contrôlés

#### Authentification et Session
- [ ] **Session Management** : Sessions sans expiration appropriée
- [ ] **Rate Limiting** : Absence de limitation des tentatives

#### Configuration et Secrets
- [ ] **Hardcoded Secrets** : Clés et mots de passe en dur
- [ ] **Information Disclosure** : Exposition de données sensibles

#### Sécurité Web
- [ ] **CSRF** : Actions sans protection contre les attaques cross-site
- [ ] **CORS Misconfiguration** : Configuration trop permissive

## 📊 Méthode d'Évaluation

Votre audit sera évalué selon :

1. **Complétude** (40%) : Nombre de vulnérabilités identifiées
2. **Précision** (30%) : Exactitude des localisations et descriptions
3. **Analyse d'impact** (20%) : Évaluation des risques
4. **Solutions proposées** (10%) : Qualité des recommandations

## 🔗 Ressources Utiles

- [OWASP Top 10 2021](https://owasp.org/Top10/)
- [OWASP API Security Top 10](https://owasp.org/www-project-api-security/)
- [CWE (Common Weakness Enumeration)](https://cwe.mitre.org/)
- [CVSS Calculator](https://www.first.org/cvss/calculator/3.1)

## 📝 Format de Rapport Attendu

```markdown
# Rapport d'Audit de Sécurité - ShopCESI

## Vulnérabilité N° : [Nom de la Vulnérabilité]
- **Fichier** : src/filename.js
- **Ligne(s)** : X-Y
- **Type OWASP** : A0X - Category Name
- **Criticité** : Critique/Élevée/Moyenne/Faible
- **Description** : [Description détaillée]
- **Impact** : [Conséquences potentielles]
- **Preuve de concept** : [Code/exemple d'exploitation]
- **Correction recommandée** : [Solution technique]
```

---

## 👥 Équipe Pédagogique

- **Cours** : INFAL 251 - Sécurité des Systèmes Applicatifs
- **Institution** : CESI
- **Niveau** : Bac+3/Bac+5

## ⚠️ Avertissement Legal

Ce code est fourni uniquement à des fins éducatives dans le cadre du cours INFAL 251. Les vulnérabilités sont intentionnelles et ne doivent jamais être reproduites dans des applications réelles. L'utilisation de ces techniques sur des systèmes non autorisés est illégale.

---

**Bonne chance dans votre audit de sécurité ! 🔍🛡️**