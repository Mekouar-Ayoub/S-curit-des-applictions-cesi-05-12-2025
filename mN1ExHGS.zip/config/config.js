// Configuration ShopCESI - Fichier de configuration principal

// ⚠️ VULNÉRABILITÉ : Secrets hardcodés en clair dans le code source
module.exports = {
    // Configuration serveur
    server: {
        port: process.env.PORT || 3000,
        host: 'localhost',
        environment: 'development'
    },

    // ⚠️ VULNÉRABILITÉ : Informations de base de données hardcodées
    database: {
        host: 'localhost',
        port: 5432,
        database: 'shopcesi',
        user: 'shopcesi_user',
        password: 'SuperSecretPassword123!',  // ⚠️ Mot de passe en clair !
        max: 20,                             // Pool de connexions
        idleTimeoutMillis: 30000
    },

    // ⚠️ VULNÉRABILITÉ : Clés JWT secrètes hardcodées
    jwt: {
        secret: 'jwt-super-secret-key-1234567890abcdef',  // ⚠️ Clé JWT en dur !
        expiresIn: '24h',
        algorithm: 'HS256'
    },

    // ⚠️ VULNÉRABILITÉ : Clés API externes exposées
    external_apis: {
        stripe_secret_key: 'sk_test_51234567890abcdef1234567890abcdef',  // ⚠️ Clé Stripe
        paypal_client_secret: 'paypal_secret_1234567890abcdef',          // ⚠️ Clé PayPal
        sendgrid_api_key: 'SG.1234567890abcdef.1234567890abcdef',        // ⚠️ Clé SendGrid
        aws_secret_access_key: 'aws_secret_key_1234567890abcdef'          // ⚠️ Clé AWS
    },

    // ⚠️ VULNÉRABILITÉ : Configuration de session avec secrets faibles
    session: {
        secret: 'session-secret-key-123',     // ⚠️ Secret de session faible
        cookie: {
            maxAge: 24 * 60 * 60 * 1000,     // 24 heures
            secure: false,                    // ⚠️ Pas de HTTPS requis
            httpOnly: true
        }
    },

    // ⚠️ VULNÉRABILITÉ : Configuration CORS permissive
    cors: {
        origin: '*',                          // ⚠️ Autorise toutes les origines !
        credentials: true,
        methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS']
    },

    // ⚠️ VULNÉRABILITÉ : Configuration de sécurité faible
    security: {
        bcrypt_rounds: 8,                     // ⚠️ Nombre de rounds trop faible
        max_login_attempts: 100,              // ⚠️ Trop d'tentatives autorisées
        lockout_time: 60000,                  // ⚠️ Verrouillage trop court (1 min)
        password_min_length: 4                // ⚠️ Mot de passe trop court
    },

    // Configuration de logging (avec infos sensibles)
    logging: {
        level: 'debug',
        include_sql_queries: true,            // ⚠️ Log des requêtes SQL
        include_request_data: true,           // ⚠️ Log des données de requête
        log_passwords: false,                 // Au moins ça...
        file_path: '/var/log/shopcesi.log'
    }
};

// ⚠️ VULNÉRABILITÉ : Export de fonction d'initialisation avec secrets
module.exports.getSecrets = function() {
    return {
        db_password: 'SuperSecretPassword123!',
        jwt_secret: 'jwt-super-secret-key-1234567890abcdef',
        admin_password: 'AdminPass2023!',     // ⚠️ Mot de passe admin en dur
        api_master_key: 'master_key_1234567890abcdef'
    };
};